export default {
    transform: {},
    testEnvironment: 'node',
    moduleFileExtensions: ['js', 'json'],
};
